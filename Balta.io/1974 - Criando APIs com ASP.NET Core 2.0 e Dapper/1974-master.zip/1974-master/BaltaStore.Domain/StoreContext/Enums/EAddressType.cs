﻿namespace BaltaStore.Domain.StoreContext.Enums
{
    public enum EAddressType
    {
        Shipping = 1,
        Billing = 2
    }
}
