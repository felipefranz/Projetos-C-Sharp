# 1941 - Criando aplicações escaláveis com arquiteturas modernas #
Repositório do curso **Criando aplicações escaláveis com arquiteturas modernas** da plataforma https://balta.io.

Autor: André Baltieri

Link: https://balta.io/cursos/1941

## Projeto construído com ##
* C#
* Design Patterns

---
balta.io - Develop Your Career

Conheça todos os cursos da plataforma em https://balta.io/cursos