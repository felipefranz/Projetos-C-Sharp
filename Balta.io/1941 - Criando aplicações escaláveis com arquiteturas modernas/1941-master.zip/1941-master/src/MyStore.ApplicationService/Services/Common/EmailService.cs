﻿namespace MyStore.ApplicationService.Services.Common
{
    public static class EmailService
    {
        public static void Send(string email, string title, string body) { }
    }
}
