﻿namespace MyStore.Domain.Account.Enums
{
    public enum ERole
    {
        User = 1,
        Admin = 2
    }
}
