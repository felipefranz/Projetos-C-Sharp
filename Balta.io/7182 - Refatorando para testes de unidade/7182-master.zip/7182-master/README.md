# Refatorando para Testes de Unidade

Para mais detalhes e video aulas, confira este curso no nosso site: 

[https://balta.io/cursos/refatorando-para-testes-de-unidade](https://balta.io/cursos/refatorando-para-testes-de-unidade)
