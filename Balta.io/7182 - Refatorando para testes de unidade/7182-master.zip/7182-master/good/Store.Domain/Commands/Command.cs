using Flunt.Notifications;

namespace Store.Domain.Commands
{
    public class Command : Notifiable
    {
        
    }
}