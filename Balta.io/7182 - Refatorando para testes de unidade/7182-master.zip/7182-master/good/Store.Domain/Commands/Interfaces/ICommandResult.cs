namespace Store.Domain.Commands.Interfaces
{
    public interface ICommandResult
    {
    }
}