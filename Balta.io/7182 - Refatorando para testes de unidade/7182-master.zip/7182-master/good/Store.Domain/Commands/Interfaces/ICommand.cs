namespace Store.Domain.Commands.Interfaces
{
    public interface ICommand
    {
        void Validate();
    }
}