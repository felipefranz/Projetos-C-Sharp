﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MinhaCalculadoraDeSignos
{
    class Signo
    {
       public int diaInicio;
       public int mesInicio;
       public int diaFim;
       public int mesFim;
       public string nome;
       public string caracteristicas;
    }
}